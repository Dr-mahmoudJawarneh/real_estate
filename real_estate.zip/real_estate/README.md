# Real Estate App UI in Flutter
Source Code - Enjoy !

# Most Important Social Media
YouTube: https://www.youtube.com/channel/UCQheyq1vvmd0RaKv1EDyGfA

I hope you liked it, and dont forget to like, subscribe, share this video with your friends, and star the repository on GitHub!

# Social Media
GitHub: https://github.com/gerfagerfa
Facebook: https://www.facebook.com/MadeWithFlutter
Twitter: https://twitter.com/AllAboutFlutter
LinkedIn: https://www.linkedin.com/in/gerfagerfa

# Inspiration
https://dribbble.com/shots/9072797-Search-Real-Estate-App